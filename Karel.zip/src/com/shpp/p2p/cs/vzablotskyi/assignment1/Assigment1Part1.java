package com.shpp.p2p.cs.vzablotskyi.assignment1;

import com.shpp.karel.KarelTheRobot;

public class Assigment1Part1 extends HelperClass {
    @Override
    public void run() throws Exception {
        pickTheNewspaper();
        goHome();
    }
}
