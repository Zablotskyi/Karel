package com.shpp.p2p.cs.vzablotskyi.assignment1;

public class Assigment3Part1 extends HelperClass {
    @Override
    public void run() throws Exception {
        putBeeperAgainstTheOppositeWall();
        moveToTheOppositeWall();
        pickBeeper();
        turnAround();
        moveToTheOppositeWall();
        pickBeeper();
    }
}
