package com.shpp.p2p.cs.vzablotskyi.assignment1;

public class Assigment2Part1 extends HelperClass {
    @Override
    public void run() throws Exception {
        fillVerticalRows();
    }

}
