package com.shpp.p2p.cs.vzablotskyi.assignment1;

public class Assigment4Part1 extends HelperClass {
    @Override
    public void run() throws Exception {
        move();
    }
}
